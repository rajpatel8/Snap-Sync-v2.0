#!/bin/bash

# /*
# * Assignment 4 
# * Course: COMP-8567 
# * Term: 2nd semester 
# * Name: Vansh Patel
# * Email: patel3hb@uwindor.ca
# * Student ID: 110176043
# * 
# * w25backup.sh 
# * Description: This script performs a series of backup operations on files in the user's home directory.
# * It creates full, incremental, differential, and size-based backups, while logging the operations.
# */

# Define backup directories and log file.
backup_dir="$HOME/backup"
fullbup_dir="$backup_dir/fullbup"
incbup_dir="$backup_dir/incbup"
diffbup_dir="$backup_dir/diffbup"
incsizebup_dir="$backup_dir/incsizebup"
log_file="$backup_dir/w25log.txt"

# Check number of arguments (should be 0 to 4)
if [ "$#" -gt 4 ]; then
    echo "Usage: $0 [filetype1] [filetype2] [filetype3] [filetype4]"
    exit 1
fi

# To run the script in background
if [ -z "$DAEMONIZED" ]; then
    # Re-launch setting the DAEMONIZED environment variable.
    nohup env DAEMONIZED=1 "$0" "$@" > /dev/null 2>&1 &
    pid=$!
    echo "Script is running in the background with PID: $pid"
    echo "To stop the script, use: kill $pid"
    echo "To view the logs, check: \$HOME/backup/w25log.txt"
    echo "To view the backup, check: \$HOME/backup"
    exit 0
fi

# Determine file type filter: if none provided, process all files.
if [ "$#" -eq 0 ]; then
    all_files=1
else
    all_files=0
    filetypes=("$@")
fi

# Create backup directories if they don't exist.
mkdir -p "$fullbup_dir" "$incbup_dir" "$diffbup_dir" "$incsizebup_dir"

# Initialize counters for sequential naming.
full_count=1
inc_count=1
diff_count=1
incsize_count=1

while true; do
    ### STEP 1: Complete backup of files 
    timestamp=$(date +"%a %e %b %Y %r %Z")
    if [ "$all_files" -eq 1 ]; then
        # Find all files under $HOME excluding the backup directory.
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -print)
    else
        # Build find command for the specified file extensions.
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f \( )
        for i in "${!filetypes[@]}"; do
            find_cmd+=(-name "*${filetypes[$i]}")
            if [ $i -lt $((${#filetypes[@]} - 1)) ]; then
                find_cmd+=(-o)
            fi
        done
        find_cmd+=(\) -print)
    fi

    tar_file="$fullbup_dir/fullbup-$full_count.tar"
    # Create the tar archive; suppress warnings by redirecting stderr.
    "${find_cmd[@]}" | tar -cf "$tar_file" -T - 2>/dev/null
    echo "$timestamp $(basename "$tar_file") was created" >> "$log_file"
    full_count=$((full_count + 1))
    
    # Create marker for STEP 1 (used by steps 2 and 4).
    marker1="/tmp/marker1.$$"
    touch "$marker1"

    // Sleep for 120 seconds.
    sleep 120

    ### STEP 2: Incremental backup (files changed after STEP 1)
    timestamp=$(date +"%a %e %b %Y %r %Z")
    if [ "$all_files" -eq 1 ]; then
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker1" -print)
    else
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker1" \( )
        for i in "${!filetypes[@]}"; do
            find_cmd+=(-name "*${filetypes[$i]}")
            if [ $i -lt $((${#filetypes[@]} - 1)) ]; then
                find_cmd+=(-o)
            fi
        done
        find_cmd+=(\) -print)
    fi

    files=$("${find_cmd[@]}")
    if [ -n "$files" ]; then
        tar_file="$incbup_dir/incbup-$inc_count.tar"
        "${find_cmd[@]}" | tar -cf "$tar_file" -T - 2>/dev/null
        echo "$timestamp $(basename "$tar_file") was created" >> "$log_file"
        inc_count=$((inc_count + 1))
    else
        echo "$timestamp No changes-Incremental backup was not created" >> "$log_file"
    fi

    # Create marker for STEP 2.
    marker2="/tmp/marker2.$$"
    touch "$marker2"

    sleep 120

    ### STEP 3: Incremental backup (files changed after STEP 2)
    timestamp=$(date +"%a %e %b %Y %r %Z")
    if [ "$all_files" -eq 1 ]; then
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker2" -print)
    else
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker2" \( )
        for i in "${!filetypes[@]}"; do
            find_cmd+=(-name "*${filetypes[$i]}")
            if [ $i -lt $((${#filetypes[@]} - 1)) ]; then
                find_cmd+=(-o)
            fi
        done
        find_cmd+=(\) -print)
    fi

    files=$("${find_cmd[@]}")
    if [ -n "$files" ]; then
        tar_file="$incbup_dir/incbup-$inc_count.tar"
        "${find_cmd[@]}" | tar -cf "$tar_file" -T - 2>/dev/null
        echo "$timestamp $(basename "$tar_file") was created" >> "$log_file"
        inc_count=$((inc_count + 1))
    else
        echo "$timestamp No changes-Incremental backup was not created" >> "$log_file"
    fi

    sleep 120

    ### STEP 4: Differential backup (files changed after STEP 1)
    timestamp=$(date +"%a %e %b %Y %r %Z")
    if [ "$all_files" -eq 1 ]; then
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker1" -print)
    else
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker1" \( )
        for i in "${!filetypes[@]}"; do
            find_cmd+=(-name "*${filetypes[$i]}")
            if [ $i -lt $((${#filetypes[@]} - 1)) ]; then
                find_cmd+=(-o)
            fi
        done
        find_cmd+=(\) -print)
    fi

    files=$("${find_cmd[@]}")
    if [ -n "$files" ]; then
        tar_file="$diffbup_dir/diffbup-$diff_count.tar"
        "${find_cmd[@]}" | tar -cf "$tar_file" -T - 2>/dev/null
        echo "$timestamp $(basename "$tar_file") was created" >> "$log_file"
        diff_count=$((diff_count + 1))
    else
        echo "$timestamp No changes-Differential backup was not created" >> "$log_file"
    fi

    # Create marker for STEP 4.
    marker4="/tmp/marker4.$$"
    touch "$marker4"

    sleep 120

    ### STEP 5: Incremental_size backup (files changed after STEP 4 with filesize >100KB)
    timestamp=$(date +"%a %e %b %Y %r %Z")
    if [ "$all_files" -eq 1 ]; then
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker4" -size +100k -print)
    else
        find_cmd=(find "$HOME" -path "$backup_dir" -prune -o -type f -newer "$marker4" -size +100k \( )
        for i in "${!filetypes[@]}"; do
            find_cmd+=(-name "*${filetypes[$i]}")
            if [ $i -lt $((${#filetypes[@]} - 1)) ]; then
                find_cmd+=(-o)
            fi
        done
        find_cmd+=(\) -print)
    fi

    files=$("${find_cmd[@]}")
    if [ -n "$files" ]; then
        tar_file="$incsizebup_dir/incsizebup-$incsize_count.tar"
        "${find_cmd[@]}" | tar -cf "$tar_file" -T - 2>/dev/null
        echo "$timestamp $(basename "$tar_file") was created" >> "$log_file"
        incsize_count=$((incsize_count + 1))
    else
        echo "$timestamp No changes-Incremental_size backup was not created" >> "$log_file"
    fi

    sleep 120

    # Remove temporary marker files before starting next cycle.
    rm -f "$marker1" "$marker2" "$marker4"

done
