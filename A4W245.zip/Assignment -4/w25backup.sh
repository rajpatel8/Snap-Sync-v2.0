#!/bin/bash

# w25backup.sh - COMP 8567 Assignment 4
# This script creates full, incremental, differential, and incremental_size backups
# based on specified file types.

# Check if the user exists
username=$(whoami)
if [ -z "$username" ]; then
    echo "Error: Cannot determine username."
    exit 1
fi

# Create necessary directories
mkdir -p ~/home/backup/fullbup
mkdir -p ~/home/backup/incbup
mkdir -p ~/home/backup/diffbup
mkdir -p ~/home/backup/incsizebup

# Initialize log file if it doesn't exist
touch ~/w25log.txt

# Initialize counters for backup files
fullbup_count=1
incbup_count=1
diffbup_count=1
incsizebup_count=1

# Set up file type filter based on arguments
if [ $# -eq 0 ]; then
    # No arguments - consider all file types
    file_types="*"
else
    # Combine arguments into a pattern for find command
    file_types=""
    for arg in "$@"; do
        if [ -z "$file_types" ]; then
            file_types="*$arg"
        else
            file_types="$file_types -o -name *$arg"
        fi
    done
fi

# Function to log messages to w25log.txt
log_message() {
    echo "$(date '+%a %d %b%Y %I:%M:%S %p %Z') $1" >> ~/w25log.txt
}

# Function to find files of specified types
find_files() {
    local pattern="$1"
    if [ "$pattern" = "*" ]; then
        find /home/$username -type f
    else
        find /home/$username -type f -name "$pattern"
    fi
}

# Function to create full backup
create_full_backup() {
    local backup_file="fullbup-$fullbup_count.tar"
    local backup_path=~/home/backup/fullbup/$backup_file
    
    if [ "$file_types" = "*" ]; then
        # For all file types
        find /home/$username -type f -print0 | tar -cf "$backup_path" --null -T -
    else
        # For specific file types
        find /home/$username -type f \( -name "$file_types" \) -print0 | tar -cf "$backup_path" --null -T -
    fi
    
    # Update timestamp for reference
    touch ~/home/backup/fullbup_timestamp
    
    # Log the backup creation
    log_message "$backup_file was created"
    
    # Increment counter for next backup 
    fullbup_count=$((fullbup_count + 1))
}

# Function to create incremental backup
create_incremental_backup() {
    local reference_time="$1"
    local backup_file="incbup-$incbup_count.tar"
    local backup_path=~/home/backup/incbup/$backup_file
    local files_found=0
    
    # Temporary file to store list of modified files
    local temp_file=$(mktemp)
    
    if [ "$file_types" = "*" ]; then
        # For all file types
        find /home/$username -type f -newer "$reference_time" -print > "$temp_file"
    else
        # For specific file types
        find /home/$username -type f \( -name "$file_types" \) -newer "$reference_time" -print > "$temp_file"
    fi
    
    # Check if any files were found
    if [ -s "$temp_file" ]; then
        tar -cf "$backup_path" -T "$temp_file"
        log_message "$backup_file was created"
        files_found=1
        incbup_count=$((incbup_count + 1))
    else
        log_message "No changes-Incremental backup was not created"
    fi
    
    # Clean up temp file
    rm "$temp_file"
    
    # Update timestamp for reference
    touch ~/home/backup/incbup_timestamp
    
    return $files_found
}

# Function to create differential backup
create_differential_backup() {
    local reference_time="$1"
    local backup_file="diffbup-$diffbup_count.tar"
    local backup_path=~/home/backup/diffbup/$backup_file
    
    # Temporary file to store list of modified files
    local temp_file=$(mktemp)
    
    if [ "$file_types" = "*" ]; then
        # For all file types
        find /home/$username -type f -newer "$reference_time" -print > "$temp_file"
    else
        # For specific file types
        find /home/$username -type f \( -name "$file_types" \) -newer "$reference_time" -print > "$temp_file"
    fi
    
    # Check if any files were found
    if [ -s "$temp_file" ]; then
        tar -cf "$backup_path" -T "$temp_file"
        log_message "$backup_file was created"
        diffbup_count=$((diffbup_count + 1))
    else
        log_message "No changes-Differential backup was not created"
    fi
    
    # Clean up temp file
    rm "$temp_file"
}

# Function to create incremental size backup
create_incremental_size_backup() {
    local reference_time="$1"
    local backup_file="incsizebup-$incsizebup_count.tar"
    local backup_path=~/home/backup/incsizebup/$backup_file
    
    # Temporary file to store list of modified files
    local temp_file=$(mktemp)
    
    if [ "$file_types" = "*" ]; then
        # For all file types
        find /home/$username -type f -newer "$reference_time" -size +100k -print > "$temp_file"
    else
        # For specific file types
        find /home/$username -type f \( -name "$file_types" \) -newer "$reference_time" -size +100k -print > "$temp_file"
    fi
    
    # Check if any files were found
    if [ -s "$temp_file" ]; then
        tar -cf "$backup_path" -T "$temp_file"
        log_message "$backup_file was created"
        incsizebup_count=$((incsizebup_count + 1))
    else
        log_message "No changes-Incremental size backup was not created"
    fi
    
    # Clean up temp file
    rm "$temp_file"
}

# Main backup loop
while true; do
    # STEP 1: Create full backup
    create_full_backup
    fullbup_timestamp=~/home/backup/fullbup_timestamp
    
    # Wait for 2 minutes
    sleep 120
    
    # STEP 2: Create first incremental backup
    create_incremental_backup "$fullbup_timestamp"
    incbup_timestamp=~/home/backup/incbup_timestamp
    
    # Wait for 2 minutes
    sleep 120
    
    # STEP 3: Create second incremental backup
    create_incremental_backup "$incbup_timestamp"
    
    # Wait for 2 minutes
    sleep 120
    
    # STEP 4: Create differential backup
    create_differential_backup "$fullbup_timestamp"
    
    # Wait for 2 minutes
    sleep 120
    
    # STEP 5: Create incremental size backup
    create_incremental_size_backup "$fullbup_timestamp"
    
    # Wait before returning to STEP 1
    sleep 120
done